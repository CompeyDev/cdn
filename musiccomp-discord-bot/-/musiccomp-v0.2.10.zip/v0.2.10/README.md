<div align="center">
  <br />
  <p>
    <a href="https://musiccomp.devcomp.tk"><img src="https://www.devcomp.tk/MusicComp-v2/assets/BotLogo.svg" width="248" alt="discord.js" /></a>
  </p>
  <br />
  <p>
    <a href="https://devcomp.tk/discord"><img src="https://img.shields.io/discord/900981890801094676?color=5865F2&logo=discord&logoColor=white" alt="Discord server" /></a>
    <a href="https://circleci.com/gh/TheAwesomeCoder05/MusicComp-v2"><img src="https://circleci.com/gh/TheAwesomeCoder05/MusicComp-v2.svg?style=svg" width="" alt="CicleCI Status" /></a>
    <a href="https://sonarcloud.io/dashboard?id=TheAwesomeCoder05_MusicComp-v2"><img src="https://sonarcloud.io/api/project_badges/measure?project=TheAwesomeCoder05_MusicComp-v2&metric=alert_status" width="" alt="Sonarcloud Status" /></a>
<a href="https://github.com/TheAwesomeCoder05/MusicComp-v2/actions"><img src="https://shields.io/github/workflow/status/TheAwesomeCoder05/MusicComp-v2/CI?event=push" width="" alt="Github Build Status" /></a>
    <a href="https://github.com/TheAwesomeCoder05/MusicComp-v2/actions"><img src="https://github.com/TheAwesomeCoder05/MusicComp-v2/actions/workflows/actions.yml/badge.svg" width="" alt="CI status" /></a>
    <a href="https://www.npmjs.com/package/musiccomp-discord-bot"><img src="https://img.shields.io/github/package-json/v/TheAwesomeCoder05/MusicComp-v2/release" width="" alt="Version" /></a>
    <a href="https://devcomp.tk/MusicComp-v2"><img src="https://img.shields.io/badge/users-600%2B-brightgreen.svg" width="" alt="Users" /></a>
  </p>
 </div>
 
 
 ## USAGE
 Refer to self hosting docs for further info.
 
 Clone this repository and switch to the release branch, or download the latest release.
 
 Then:
 ```
 bash -f setup.sh
 ```
 
 The script should install the required binaries and packages. 
