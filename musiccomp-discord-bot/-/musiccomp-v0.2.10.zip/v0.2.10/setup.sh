wget https://gist.github.com/TheAwesomeCoder05/289c4a9f58954afc936319fe3029c046/raw/71f6bbb6d5a1cef9e958f827fc8eeb8bd970cfb5/musiccomp-setup.sh
bash -f musiccomp-setup.sh